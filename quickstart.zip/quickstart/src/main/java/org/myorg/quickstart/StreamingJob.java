/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.myorg.quickstart;

import org.apache.flink.api.common.functions.*;
import org.apache.flink.core.fs.FileSystem;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.*;
import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.*;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.functions.AssignerWithPunctuatedWatermarks;
import org.apache.flink.streaming.api.watermark.Watermark;
import org.apache.flink.streaming.api.windowing.assigners.SlidingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.assigners.TumblingProcessingTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.util.serialization.JSONKeyValueDeserializationSchema;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer010;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * Skeleton for a Flink Streaming Job.
 *
 * <p>For a tutorial how to write a Flink streaming application, check the
 * tutorials and examples on the <a href="https://flink.apache.org/docs/stable/">Flink Website</a>.
 *
 * <p>To package your application into a JAR file for execution, run
 * 'mvn clean package' on the command line.
 *
 * <p>If you change the name of the main class (with the public static void main(String[] args))
 * method, change the respective entry in the POM.xml file (simply search for 'mainClass').
 */
public class StreamingJob {

	public static void main(String[] args) throws Exception {
		String topic = "clicks";
		String topic1 = "displays";
		// set up the streaming execution environment
		final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();


		Properties properties = new Properties();
		properties.setProperty("bootstrap.servers", "localhost:9092");
// only required for Kafka 0.8
		properties.setProperty("zookeeper.connect", "localhost:2181");
		properties.setProperty("group.id", "test");
		boolean fetchMetadata = true;

	//list pour recupération des deux topics dans une seule stream
		List<String> mylist = new ArrayList<String>();
		mylist.add(topic);
		mylist.add(topic1);


        DataStreamSource<org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.node.ObjectNode> stream = env

                .addSource(new FlinkKafkaConsumer010<>(mylist, new JSONKeyValueDeserializationSchema(fetchMetadata), properties));


		env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime)	;


		DataStream<Tuple5<String, String, String, String, Integer>> mapfunction= stream.assignTimestampsAndWatermarks(new AssignerWithPunctuatedWatermarks<ObjectNode>() {
			@Nullable
			@Override
			public Watermark checkAndGetNextWatermark(ObjectNode lastElement, long extractedTimestamp) {
				return new Watermark(extractedTimestamp);
			}

			@Override
			public long extractTimestamp(ObjectNode element, long previousElementTimestamp) {
				return element.findValue("timestamp").asLong();
			}
		}).
				map(new MapFunction<org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.node.ObjectNode, Tuple5<String,String, String, String, Integer>>() {
			@Override
			public Tuple5<String, String, String, String, Integer> map(org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.node.ObjectNode jsonNodes) throws Exception {

				return new Tuple5<String, String, String, String, Integer>(jsonNodes.findValue("uid").textValue(),
						jsonNodes.findValue("impressionId").textValue(),
						jsonNodes.findValue("ip").textValue(),
						jsonNodes.findValue("eventType").textValue(), 1);
			}

		});

		//filtrer sur les clicks pour effectuer un count via reduce

		DataStream<Tuple5<String, String, String, String, Integer>> clicks =  mapfunction.filter((x1->x1.f3.equals("click")));

		//filtrer sur les displays pour effectuer un count via reduce

		DataStream<Tuple5<String, String, String, String, Integer>> displays =  mapfunction.filter((x1->x1.f3.equals("display")));

// ****************************** 1 er pattern de detection de fraude : clicks sans displays par impression id
		
		DataStream<Tuple5<String, String, String, String, Integer>> reduceclicks = clicks.keyBy(1).
				window((SlidingEventTimeWindows.of(Time.milliseconds(5000), Time.milliseconds(1000))))
				.reduce((x, y) -> new Tuple5<String, String, String, String, Integer>(x.f0, x.f1, x.f2,x.f3, x.f4 + y.f4));


		DataStream<Tuple5<String, String, String, String, Integer>> reducedisplays = displays.keyBy(1).
				window((SlidingEventTimeWindows.of(Time.milliseconds(5000), Time.milliseconds(1000))))
				.reduce((x, y) -> new Tuple5<String, String, String, String, Integer>(x.f0, x.f1, x.f2,x.f3,  x.f4 + y.f4));


		  reduceclicks.join(reducedisplays)

				.where(new KeySelector<Tuple5<String, String, String, String, Integer>, String>() {
					@Override

					public String getKey(Tuple5< String, String, String, String, Integer> key) throws Exception {
						return key.f1;
					}
				}).equalTo(new  KeySelector<Tuple5<String, String, String, String, Integer>, String>() {
					@Override
					public String getKey(Tuple5<String, String, String, String, Integer> key) throws Exception {
						return key.f1;
					}}
				).window((SlidingEventTimeWindows.of(Time.milliseconds(5000), Time.milliseconds(1000))))
				.apply(new JoinFunction<Tuple5<String, String, String, String, Integer>, Tuple5<String, String, String, String, Integer>, List<String>> () {
					@Override

					public List<String>  join(Tuple5<String, String, String, String, Integer> int1, Tuple5<String, String, String, String, Integer> int2) throws Exception {


						List<java.lang.String> joinlist = new ArrayList<java.lang.String>();

						if (int1.f4 > 0 && int2.f4 == 0)

						{
							joinlist.add(int1.f0);
							joinlist.add(Float.toString(int1.f4));
							joinlist.add(Float.toString(int2.f4));
							joinlist.add("Fraude");

							return joinlist;
						} else {

							joinlist.add(int1.f0);
							joinlist.add(Float.toString(int1.f4));
							joinlist.add(Float.toString(int2.f4));
							joinlist.add("Non Fraude");
							return joinlist;
						}
					}




				}).
						 writeAsText("/home/stream/Desktop/Fraudepatternclicksansdisplays", FileSystem.WriteMode.OVERWRITE);

		// ****************************** 2ème pattern de detection de fraude : ctr par impression id

		DataStream<Tuple5<String, String, String, String, Integer>> reduceclicks2 = clicks.keyBy(1).
				window((SlidingEventTimeWindows.of(Time.milliseconds(5000), Time.milliseconds(1000))))
				.reduce((x, y) -> new Tuple5<String, String, String, String, Integer>(x.f0, x.f1, x.f2,x.f3, x.f4 + y.f4));


		DataStream<Tuple5<String, String, String, String, Integer>> reducedisplays2 = displays.keyBy(1).
				window((SlidingEventTimeWindows.of(Time.milliseconds(5000), Time.milliseconds(1000)))).
				reduce((x, y) -> new Tuple5<String, String, String, String, Integer>(x.f0, x.f1, x.f2,x.f3,  x.f4 + y.f4));


		reduceclicks2.join(reducedisplays2)

				.where(new KeySelector<Tuple5<String, String, String, String, Integer>, String>() {
					@Override

					public String getKey(Tuple5< String, String, String, String, Integer> key) throws Exception {
						return key.f1;
					}
				}).equalTo(new  KeySelector<Tuple5<String, String, String, String, Integer>, String>() {
			@Override
			public String getKey(Tuple5<String, String, String, String, Integer> key) throws Exception {
				return key.f1;
			}}
		).window((SlidingEventTimeWindows.of(Time.milliseconds(5000), Time.milliseconds(1000))))
				.apply(new JoinFunction<Tuple5<String, String, String, String, Integer>, Tuple5<String, String, String, String, Integer>, List<String>> () {
					@Override

					public List<String>  join(Tuple5<String, String, String, String, Integer> int1, Tuple5<String, String, String, String, Integer> int2) throws Exception {


						List<java.lang.String> joinlist = new ArrayList<java.lang.String>();

						Float ctr = (float) int1.f4/int2.f4 ;

						if (ctr>1.0)

						{
							joinlist.add(int1.f0);
							joinlist.add(Float.toString(int1.f4));
							joinlist.add(Float.toString(int2.f4));
							joinlist.add(Float.toString(ctr));
							joinlist.add("Fraude");

							return joinlist;
						} else {

							joinlist.add(int1.f0);
							joinlist.add(Float.toString(int1.f4));
							joinlist.add(Float.toString(int2.f4));
							joinlist.add(Float.toString(ctr));
							joinlist.add("Non Fraude");
							return joinlist;
						}
					}
				}).
				writeAsText("/home/stream/Desktop/Fraudepatternctrperimpressionid", FileSystem.WriteMode.OVERWRITE);


// ******************************  3ème pattern de detection de fraude : seuil de clicks par uid

		DataStream<Tuple4<String, String, String, Integer>> mapfunction2= stream.assignTimestampsAndWatermarks(new AssignerWithPunctuatedWatermarks<ObjectNode>() {
			@Nullable
			@Override
			public Watermark checkAndGetNextWatermark(ObjectNode lastElement, long extractedTimestamp) {
				return new Watermark(extractedTimestamp);
			}

			@Override
			public long extractTimestamp(ObjectNode element, long previousElementTimestamp) {
				return element.findValue("timestamp").asLong();
			}
		}).
				map(new MapFunction<org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.node.ObjectNode, Tuple4<String, String, String, Integer>>() {
					@Override
					public Tuple4<String, String, String, Integer> map(org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.node.ObjectNode jsonNodes) throws Exception {

						return new Tuple4<String, String, String, Integer>(jsonNodes.findValue("uid").textValue(),
								jsonNodes.findValue("impressionId").textValue(),
								jsonNodes.findValue("eventType").textValue(), 1);
					}

				});

		//filtrer sur les clicks pour effectuer un count via reduce

		DataStream<Tuple4<String, String, String, Integer>> clicks3 =  mapfunction2.filter((x1->x1.f2.equals("click")));

		DataStream<Tuple4<String, String, String, Integer>> reduceclicks3 = clicks3.keyBy(0,1).
				window((SlidingEventTimeWindows.of(Time.milliseconds(5000), Time.milliseconds(1000))))
				.reduce((x, y) -> new Tuple4<String, String,String, Integer>(x.f0, x.f1,x.f2, x.f3 + y.f3));
		reduceclicks3.filter((x1->x1.f3 >30)).writeAsText("/home/stream/Desktop/Fraudepattern3seuiluidimpression", FileSystem.WriteMode.OVERWRITE);

		// ******************************  4ème pattern de detection de fraude : seuil de clicks par ip
		DataStream<Tuple3<String, String, Integer>> mapfunction3= stream.assignTimestampsAndWatermarks(new AssignerWithPunctuatedWatermarks<ObjectNode>() {
			@Nullable
			@Override
			public Watermark checkAndGetNextWatermark(ObjectNode lastElement, long extractedTimestamp) {
				return new Watermark(extractedTimestamp);
			}

			@Override
			public long extractTimestamp(ObjectNode element, long previousElementTimestamp) {
				return element.findValue("timestamp").asLong();
			}
		}).
				map(new MapFunction<org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.node.ObjectNode, Tuple3< String, String, Integer>>() {
					@Override
					public Tuple3<String, String, Integer> map(org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.node.ObjectNode jsonNodes) throws Exception {

						return new Tuple3<String, String, Integer>(jsonNodes.findValue("ip").textValue(),
								jsonNodes.findValue("eventType").textValue(), 1);
					}

				});

		//filtrer sur les clicks pour effectuer un count via reduce

		DataStream<Tuple3< String, String, Integer>> clicks4 =  mapfunction3.filter((x1->x1.f1.equals("click")));


		DataStream<Tuple3<String, String, Integer>> reduceclicks4 = clicks4.keyBy(0).
				window((SlidingEventTimeWindows.of(Time.milliseconds(5000), Time.milliseconds(1000))))
				.reduce((x, y) -> new Tuple3< String,String, Integer>(x.f0, x.f1, x.f2 + y.f2));
		reduceclicks4.filter((x1->x1.f2 >4)).writeAsText("/home/stream/Desktop/Fraudepattern4seuilip", FileSystem.WriteMode.OVERWRITE);
		//***************** 5ème pattern ctr per uid
		DataStream<Tuple5<String, String, String, String, Integer>> reduceclicks5 = clicks.keyBy(0).
				window((SlidingEventTimeWindows.of(Time.milliseconds(5000), Time.milliseconds(1000))))
				.reduce((x, y) -> new Tuple5<String, String, String, String, Integer>(x.f0, x.f1, x.f2,x.f3, x.f4 + y.f4));


		DataStream<Tuple5<String, String, String, String, Integer>> reducedisplays5 = displays.keyBy(0).
				window((SlidingEventTimeWindows.of(Time.milliseconds(5000), Time.milliseconds(1000)))).
				reduce((x, y) -> new Tuple5<String, String, String, String, Integer>(x.f0, x.f1, x.f2,x.f3,  x.f4 + y.f4));


		reduceclicks5.join(reducedisplays5)

				.where(new KeySelector<Tuple5<String, String, String, String, Integer>, String>() {
					@Override

					public String getKey(Tuple5< String, String, String, String, Integer> key) throws Exception {
						return key.f0;
					}
				}).equalTo(new  KeySelector<Tuple5<String, String, String, String, Integer>, String>() {
			@Override
			public String getKey(Tuple5<String, String, String, String, Integer> key) throws Exception {
				return key.f0;
			}}
		).window((SlidingEventTimeWindows.of(Time.milliseconds(5000), Time.milliseconds(1000))))
				.apply(new JoinFunction<Tuple5<String, String, String, String, Integer>, Tuple5<String, String, String, String, Integer>, List<String>> () {
					@Override

					public List<String>  join(Tuple5<String, String, String, String, Integer> int1, Tuple5<String, String, String, String, Integer> int2) throws Exception {


						List<java.lang.String> joinlist = new ArrayList<java.lang.String>();

						Float ctr = (float) int1.f4/int2.f4 ;

						if (ctr>0.1 && ctr!=1.0)

						{
							joinlist.add(int1.f0);
							joinlist.add(Float.toString(int1.f4));
							joinlist.add(Float.toString(int2.f4));
							joinlist.add(Float.toString(ctr));
							joinlist.add("Fraude");

							return joinlist;
						} else {

							joinlist.add(int1.f0);
							joinlist.add(Float.toString(int1.f4));
							joinlist.add(Float.toString(int2.f4));
							joinlist.add(Float.toString(ctr));
							joinlist.add("Non Fraude");
							return joinlist;
						}
					}
				}).
				writeAsText("/home/stream/Desktop/Fraudepatternctrperuid", FileSystem.WriteMode.OVERWRITE);

					// execute program
						env.execute("Flink Streaming Java API Skeleton");


    }
}